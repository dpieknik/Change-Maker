const $ = selector => document.querySelector(selector);

'use strict';

//Change Calculator

$("#cents").focus();        //focus on user entry box

let changeAmount;
let quarters = 0;
let dimes = 0;
let nickels = 0;
let pennies = 0;

//This function inputs the change amount and outputs the number of quarters, dimes, nickels, and pennies owed to the customer

function makeChange(changeAmount) {

  quarters = $("#quarters").value = Math.floor(changeAmount / 25);   //Determine number of quarters
  changeAmount %= 25;

  dimes = $("#dimes").value = Math.floor(changeAmount / 10);    //Determine number of dimes
  changeAmount %= 10;

  nickels = $("#nickels").value = Math.floor(changeAmount / 5);   //Determine number of nickles
  changeAmount %= 5;

  pennies = $("#pennies").value = changeAmount;

  alert(`Your change is ${quarters} quarters, ${dimes} dimes, ${nickels} nickels, and ${pennies} pennies.`);

  $("#cents").focus();        //refocus on user entry box
}

//This function resets the form values so it can run again

function clearBoxes() {
    $("#quarters").value = "";
    $("#dimes").value = "";
    $("#nickels").value = "";
    $("#pennies").value = "";
}


function processEntry() {
  clearBoxes();                                     //Clears form for clean run

  changeAmount = parseInt($("#cents").value);       //Set changeAmount variable to user entry

  //Error check user entry for valid data
  
  if(!Number.isNaN(changeAmount) && Number.isInteger(changeAmount) && changeAmount > 0 && changeAmount < 100) {
    makeChange(changeAmount);
  } else {
    alert("Invalid entry. Please enter a whole number between 0 and 100.")
  }


}

$("#calculate").addEventListener("click", processEntry);        //load button with processEntry function